# Pokémon Damage Calculator

A simple Pokémon damage calculator_ver.2.

## Installation

You can install the package via pip:

```sh
pip install pokemon_damage_calculator
